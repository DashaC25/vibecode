"""Test the split calculator functionality."""

import asyncio
import sys
from src.processors.split_calculator import SplitCalculator


def test_basic_split():
    """Test basic split with 2 people, no shared items."""
    print("\n=== Test 1: Basic Split (No Sharing) ===")

    calculator = SplitCalculator()

    # Mock data: 2 people, simple orders
    participants_data = [
        {
            "name": "You",
            "participant_id": 1,
            "orders": [
                {
                    "receipt_item_id": 1,
                    "receipt_item_name": "Burger",
                    "unit_price": 12.99,
                    "quantity_share": 1.0,
                }
            ],
        },
        {
            "name": "Sarah",
            "participant_id": 2,
            "orders": [
                {
                    "receipt_item_id": 2,
                    "receipt_item_name": "Salad",
                    "unit_price": 9.99,
                    "quantity_share": 1.0,
                }
            ],
        },
    ]

    receipt_data = {
        "subtotal": 22.98,
        "tax": 2.30,
        "tip": 4.60,
        "total": 29.88,
    }

    result = calculator.calculate_split(participants_data, receipt_data, "proportional")

    print(f"Receipt Total: ${receipt_data['total']:.2f}")
    print(f"\nParticipants:")
    for p in result["participants"]:
        print(f"  {p['name']}:")
        print(f"    Items: ${p['items_subtotal']:.2f}")
        print(f"    Tax: ${p['tax_share']:.2f}")
        print(f"    Tip: ${p['tip_share']:.2f}")
        print(f"    TOTAL: ${p['final_total']:.2f}")

    # Verify totals add up
    total_calc = sum(p["final_total"] for p in result["participants"])
    print(f"\nVerification:")
    print(f"  Sum of splits: ${total_calc:.2f}")
    print(f"  Receipt total: ${receipt_data['total']:.2f}")
    print(f"  Difference: ${abs(total_calc - receipt_data['total']):.2f}")

    assert abs(total_calc - receipt_data["total"]) < 0.01, "Totals don't match!"
    print("  ✅ PASS: Totals match!\n")

    return result


def test_shared_items():
    """Test split with shared items (50/50)."""
    print("\n=== Test 2: Split with Shared Items ===")

    calculator = SplitCalculator()

    # Mock data: 2 people sharing fries
    participants_data = [
        {
            "name": "You",
            "participant_id": 1,
            "orders": [
                {
                    "receipt_item_id": 1,
                    "receipt_item_name": "Burger",
                    "unit_price": 12.99,
                    "quantity_share": 1.0,
                },
                {
                    "receipt_item_id": 3,
                    "receipt_item_name": "Fries",
                    "unit_price": 4.99,
                    "quantity_share": 0.5,  # Split 50/50
                },
            ],
        },
        {
            "name": "Sarah",
            "participant_id": 2,
            "orders": [
                {
                    "receipt_item_id": 2,
                    "receipt_item_name": "Salad",
                    "unit_price": 9.99,
                    "quantity_share": 1.0,
                },
                {
                    "receipt_item_id": 3,
                    "receipt_item_name": "Fries",
                    "unit_price": 4.99,
                    "quantity_share": 0.5,  # Split 50/50
                },
            ],
        },
    ]

    receipt_data = {
        "subtotal": 27.97,  # 12.99 + 9.99 + 4.99
        "tax": 2.80,
        "tip": 5.60,
        "total": 36.37,
    }

    result = calculator.calculate_split(participants_data, receipt_data, "proportional")

    print(f"Receipt Total: ${receipt_data['total']:.2f}")
    print(f"\nParticipants:")
    for p in result["participants"]:
        print(f"  {p['name']}:")
        for item in p["items"]:
            if item["quantity_share"] < 1.0:
                print(f"    - {item['name']}: ${item['item_total']:.2f} ({item['quantity_share']*100:.0f}% share)")
            else:
                print(f"    - {item['name']}: ${item['item_total']:.2f}")
        print(f"    Subtotal: ${p['items_subtotal']:.2f}")
        print(f"    Tax: ${p['tax_share']:.2f}")
        print(f"    Tip: ${p['tip_share']:.2f}")
        print(f"    TOTAL: ${p['final_total']:.2f}")

    # Verify totals add up
    total_calc = sum(p["final_total"] for p in result["participants"])
    print(f"\nVerification:")
    print(f"  Sum of splits: ${total_calc:.2f}")
    print(f"  Receipt total: ${receipt_data['total']:.2f}")
    print(f"  Difference: ${abs(total_calc - receipt_data['total']):.2f}")

    assert abs(total_calc - receipt_data["total"]) < 0.01, "Totals don't match!"
    print("  ✅ PASS: Totals match!\n")

    return result


def test_three_way_split():
    """Test split with 3 people sharing an item."""
    print("\n=== Test 3: Three-Way Split ===")

    calculator = SplitCalculator()

    # Mock data: 3 people sharing pizza
    participants_data = [
        {
            "name": "You",
            "participant_id": 1,
            "orders": [
                {
                    "receipt_item_id": 1,
                    "receipt_item_name": "Pizza",
                    "unit_price": 18.99,
                    "quantity_share": 0.33,  # 1/3
                },
            ],
        },
        {
            "name": "Sarah",
            "participant_id": 2,
            "orders": [
                {
                    "receipt_item_id": 1,
                    "receipt_item_name": "Pizza",
                    "unit_price": 18.99,
                    "quantity_share": 0.33,  # 1/3
                },
            ],
        },
        {
            "name": "Mike",
            "participant_id": 3,
            "orders": [
                {
                    "receipt_item_id": 1,
                    "receipt_item_name": "Pizza",
                    "unit_price": 18.99,
                    "quantity_share": 0.34,  # 1/3 + rounding
                },
            ],
        },
    ]

    receipt_data = {
        "subtotal": 18.99,
        "tax": 1.90,
        "tip": 3.80,
        "total": 24.69,
    }

    result = calculator.calculate_split(participants_data, receipt_data, "proportional")

    print(f"Receipt Total: ${receipt_data['total']:.2f}")
    print(f"\nParticipants:")
    for p in result["participants"]:
        print(f"  {p['name']}:")
        for item in p["items"]:
            print(f"    - {item['name']}: ${item['item_total']:.2f} ({item['quantity_share']*100:.0f}% share)")
        print(f"    Tax: ${p['tax_share']:.2f}")
        print(f"    Tip: ${p['tip_share']:.2f}")
        print(f"    TOTAL: ${p['final_total']:.2f}")

    # Verify totals add up
    total_calc = sum(p["final_total"] for p in result["participants"])
    print(f"\nVerification:")
    print(f"  Sum of splits: ${total_calc:.2f}")
    print(f"  Receipt total: ${receipt_data['total']:.2f}")
    print(f"  Difference: ${abs(total_calc - receipt_data['total']):.2f}")

    assert abs(total_calc - receipt_data["total"]) < 0.01, "Totals don't match!"
    print("  ✅ PASS: Totals match!\n")

    return result


def test_equal_distribution():
    """Test equal tax/tip distribution instead of proportional."""
    print("\n=== Test 4: Equal Tax/Tip Distribution ===")

    calculator = SplitCalculator()

    # Person 1 orders expensive item, Person 2 orders cheap item
    participants_data = [
        {
            "name": "You",
            "participant_id": 1,
            "orders": [
                {
                    "receipt_item_id": 1,
                    "receipt_item_name": "Steak",
                    "unit_price": 35.99,
                    "quantity_share": 1.0,
                },
            ],
        },
        {
            "name": "Sarah",
            "participant_id": 2,
            "orders": [
                {
                    "receipt_item_id": 2,
                    "receipt_item_name": "Soup",
                    "unit_price": 8.99,
                    "quantity_share": 1.0,
                },
            ],
        },
    ]

    receipt_data = {
        "subtotal": 44.98,
        "tax": 4.50,
        "tip": 9.00,
        "total": 58.48,
    }

    # Test proportional
    result_prop = calculator.calculate_split(participants_data, receipt_data, "proportional")

    print(f"Receipt Total: ${receipt_data['total']:.2f}")
    print(f"\nProportional Distribution:")
    for p in result_prop["participants"]:
        print(f"  {p['name']}: ${p['final_total']:.2f} (tax: ${p['tax_share']:.2f}, tip: ${p['tip_share']:.2f})")

    # Test equal
    result_equal = calculator.calculate_split(participants_data, receipt_data, "equal")

    print(f"\nEqual Distribution:")
    for p in result_equal["participants"]:
        print(f"  {p['name']}: ${p['final_total']:.2f} (tax: ${p['tax_share']:.2f}, tip: ${p['tip_share']:.2f})")

    # Verify both add up
    total_prop = sum(p["final_total"] for p in result_prop["participants"])
    total_equal = sum(p["final_total"] for p in result_equal["participants"])

    print(f"\nVerification:")
    print(f"  Proportional sum: ${total_prop:.2f}")
    print(f"  Equal sum: ${total_equal:.2f}")
    print(f"  Receipt total: ${receipt_data['total']:.2f}")

    assert abs(total_prop - receipt_data["total"]) < 0.01, "Proportional totals don't match!"
    assert abs(total_equal - receipt_data["total"]) < 0.01, "Equal totals don't match!"
    print("  ✅ PASS: Both methods match!\n")

    return result_prop, result_equal


def test_format_output():
    """Test the formatting functions."""
    print("\n=== Test 5: Format Output ===")

    calculator = SplitCalculator()

    participants_data = [
        {
            "name": "You",
            "participant_id": 1,
            "orders": [
                {
                    "receipt_item_id": 1,
                    "receipt_item_name": "Burger",
                    "unit_price": 12.99,
                    "quantity_share": 1.0,
                }
            ],
        },
        {
            "name": "Sarah",
            "participant_id": 2,
            "orders": [
                {
                    "receipt_item_id": 2,
                    "receipt_item_name": "Salad",
                    "unit_price": 9.99,
                    "quantity_share": 1.0,
                }
            ],
        },
    ]

    receipt_data = {
        "subtotal": 22.98,
        "tax": 2.30,
        "tip": 4.60,
        "total": 29.88,
    }

    result = calculator.calculate_split(participants_data, receipt_data, "proportional")

    # Test summary format
    print("\n--- Summary Format ---")
    summary = calculator.format_split_results(result)
    print(summary)

    # Test detailed format
    print("\n--- Detailed Format ---")
    detailed = calculator.format_detailed_breakdown(result)
    print(detailed)

    print("  ✅ PASS: Formatting works!\n")


if __name__ == "__main__":
    print("=" * 60)
    print("TESTING SPLIT CALCULATOR")
    print("=" * 60)

    try:
        test_basic_split()
        test_shared_items()
        test_three_way_split()
        test_equal_distribution()
        test_format_output()

        print("=" * 60)
        print("✅ ALL TESTS PASSED!")
        print("=" * 60)

    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
