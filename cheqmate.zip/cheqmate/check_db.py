"""Check database state to see if splits are being saved."""

from sqlalchemy import create_engine, text

# Connect to the database
engine = create_engine("sqlite:///cheqmate.db")

with engine.connect() as conn:
    print("=== BILL SESSIONS ===")
    sessions = conn.execute(text("SELECT * FROM bill_sessions ORDER BY created_at DESC LIMIT 5")).fetchall()
    for session in sessions:
        print(f"Session {session[0]}: user={session[1]}, state={session[3]}, created={session[4]}")

    print("\n=== RECEIPTS ===")
    receipts = conn.execute(text("SELECT * FROM receipts ORDER BY created_at DESC LIMIT 5")).fetchall()
    for receipt in receipts:
        count = conn.execute(text('SELECT COUNT(*) FROM receipt_items WHERE receipt_id = :id'), {"id": receipt[0]}).scalar()
        print(f"Receipt {receipt[0]}: session={receipt[1]}, total=${receipt[7]}, items_count={count}")

    print("\n=== PARTICIPANTS ===")
    participants = conn.execute(text("SELECT * FROM participants ORDER BY created_at DESC LIMIT 10")).fetchall()
    for participant in participants:
        print(f"Participant {participant[0]}: session={participant[1]}, name='{participant[2]}'")

    print("\n=== PARTICIPANT ORDERS ===")
    orders = conn.execute(text("SELECT * FROM participant_orders ORDER BY created_at DESC LIMIT 10")).fetchall()
    for order in orders:
        print(f"Order {order[0]}: participant={order[1]}, receipt_item={order[2]}, quantity_share={order[3]}")

    print("\n=== BILL SPLITS ===")
    splits = conn.execute(text("SELECT * FROM bill_splits ORDER BY created_at DESC LIMIT 5")).fetchall()
    if splits:
        for split in splits:
            print(f"Split {split[0]}: session={split[1]}, version={split[2]}, active={split[3]}, method={split[4]}")
    else:
        print("No bill splits found!")

    print("\n=== PARTICIPANT SPLITS ===")
    participant_splits = conn.execute(text("SELECT * FROM participant_splits ORDER BY created_at DESC LIMIT 10")).fetchall()
    if participant_splits:
        for psplit in participant_splits:
            print(f"ParticipantSplit {psplit[0]}: split={psplit[1]}, participant={psplit[2]}, final_total=${psplit[6]}")
    else:
        print("No participant splits found!")
