"""Test saving ParticipantSplit to database."""

from src.models.database import get_db_session, init_db
from src.models.bill_session import BillSession, SessionState
from src.models.bill_split import BillSplit, ParticipantSplit
from src.models.participant import Participant

# Initialize database
init_db()

# Create a test session
with get_db_session() as db:
    # Create bill session
    session = BillSession(
        user_id=123,
        chat_id=123,
        state=SessionState.WAITING_FOR_RECEIPT,
    )
    db.add(session)
    db.flush()
    print(f"Created session {session.id}")

    # Create participant
    participant = Participant(
        session_id=session.id,
        name="Test User",
    )
    db.add(participant)
    db.flush()
    print(f"Created participant {participant.id}")

    # Create bill split
    bill_split = BillSplit(
        session_id=session.id,
        version=1,
        is_active=True,
        distribution_method="proportional",
    )
    db.add(bill_split)
    db.flush()
    print(f"Created bill_split {bill_split.id}")

    # Create participant split with specific values
    print("\nCreating ParticipantSplit with:")
    print("  items_subtotal=12.99")
    print("  tax_share=1.30")
    print("  tip_share=2.60")
    print("  final_total=16.89")

    participant_split = ParticipantSplit(
        bill_split_id=bill_split.id,
        participant_id=participant.id,
        items_subtotal=12.99,
        tax_share=1.30,
        tip_share=2.60,
        final_total=16.89,
        confirmed_by_user=True,
    )

    print("\nBefore adding to session:")
    print(f"  items_subtotal={participant_split.items_subtotal}")
    print(f"  tax_share={participant_split.tax_share}")
    print(f"  tip_share={participant_split.tip_share}")
    print(f"  final_total={participant_split.final_total}")

    db.add(participant_split)

    print("\nAfter adding to session:")
    print(f"  items_subtotal={participant_split.items_subtotal}")
    print(f"  tax_share={participant_split.tax_share}")
    print(f"  tip_share={participant_split.tip_share}")
    print(f"  final_total={participant_split.final_total}")

    db.flush()

    print("\nAfter flush:")
    print(f"  items_subtotal={participant_split.items_subtotal}")
    print(f"  tax_share={participant_split.tax_share}")
    print(f"  tip_share={participant_split.tip_share}")
    print(f"  final_total={participant_split.final_total}")

    db.commit()

    print("\nAfter commit:")
    print(f"  items_subtotal={participant_split.items_subtotal}")
    print(f"  tax_share={participant_split.tax_share}")
    print(f"  tip_share={participant_split.tip_share}")
    print(f"  final_total={participant_split.final_total}")

# Re-read from database
print("\n\nRe-reading from database...")
with get_db_session() as db:
    saved_split = db.query(ParticipantSplit).first()
    if saved_split:
        print(f"Read ParticipantSplit {saved_split.id}:")
        print(f"  items_subtotal={saved_split.items_subtotal}")
        print(f"  tax_share={saved_split.tax_share}")
        print(f"  tip_share={saved_split.tip_share}")
        print(f"  final_total={saved_split.final_total}")
        print(f"  manual_adjustment={saved_split.manual_adjustment}")

        if saved_split.items_subtotal != 12.99:
            print("\n❌ BUG FOUND! items_subtotal is wrong!")
        else:
            print("\n✅ Values saved correctly!")
    else:
        print("No ParticipantSplit found in database")
