"""Check what was actually saved vs what should have been saved."""

from sqlalchemy import create_engine, text

# Connect to the database
engine = create_engine("sqlite:///cheqmate.db")

with engine.connect() as conn:
    session_id = 2

    print("=== WHAT WAS SAVED IN THE DATABASE ===\n")

    # Get participant splits with details
    splits = conn.execute(
        text("""
            SELECT ps.id, p.name, ps.items_subtotal, ps.tax_share, ps.tip_share, ps.final_total
            FROM participant_splits ps
            JOIN bill_splits bs ON ps.bill_split_id = bs.id
            JOIN participants p ON ps.participant_id = p.id
            WHERE bs.session_id = :sid
            ORDER BY p.name
        """),
        {"sid": session_id}
    ).fetchall()

    for split in splits:
        print(f"{split[1]}:")
        print(f"  Items subtotal: ${split[2]:.2f}")
        print(f"  Tax share: ${split[3]:.2f}")
        print(f"  Tip share: ${split[4]:.2f}")
        print(f"  Final total: ${split[5]:.2f}")
        print()
