"""Debug the split issue - reproduce what the bot is doing."""

from sqlalchemy import create_engine, text
from src.processors.split_calculator import SplitCalculator

# Connect to the database
engine = create_engine("sqlite:///cheqmate.db")

with engine.connect() as conn:
    # Get session 2
    session_id = 2

    print(f"=== DEBUG SESSION {session_id} ===\n")

    # Get receipt info
    receipt = conn.execute(
        text("SELECT * FROM receipts WHERE session_id = :id"),
        {"id": session_id}
    ).fetchone()

    print(f"Receipt total: ${receipt[7]}")
    print(f"Receipt subtotal: ${receipt[4]}")
    print(f"Receipt tax: ${receipt[5]}")
    print(f"Receipt tip: ${receipt[6]}\n")

    # Get receipt items
    print("Receipt items:")
    items = conn.execute(
        text("SELECT * FROM receipt_items WHERE receipt_id = :id ORDER BY id"),
        {"id": receipt[0]}
    ).fetchall()

    for item in items:
        print(f"  Item {item[0]}: {item[2]} (qty={item[3]}, unit_price=${item[4]}, total=${item[5]})")

    # Get participants
    print("\nParticipants and their orders:")
    participants = conn.execute(
        text("SELECT * FROM participants WHERE session_id = :id ORDER BY id"),
        {"id": session_id}
    ).fetchall()

    participants_data = []

    for participant in participants:
        print(f"\n  {participant[2]} (ID: {participant[0]}):")

        # Get orders for this participant
        orders = conn.execute(
            text("""
                SELECT po.*, ri.item_name, ri.unit_price, ri.total_price
                FROM participant_orders po
                JOIN receipt_items ri ON po.receipt_item_id = ri.id
                WHERE po.participant_id = :id
                ORDER BY po.id
            """),
            {"id": participant[0]}
        ).fetchall()

        orders_list = []
        for order in orders:
            print(f"    - {order[6]} (qty_share={order[3]}, unit_price=${order[7]})")
            orders_list.append({
                "receipt_item_id": order[2],
                "receipt_item_name": order[6],
                "unit_price": order[7],
                "quantity_share": order[3],
            })

        participants_data.append({
            "name": participant[2],
            "participant_id": participant[0],
            "orders": orders_list,
        })

    # Now calculate the split
    print("\n\n=== CALCULATING SPLIT ===\n")

    receipt_data = {
        "subtotal": receipt[4] or receipt[7],
        "tax": receipt[5] or 0.0,
        "tip": receipt[6] or 0.0,
        "total": receipt[7],
    }

    calculator = SplitCalculator()
    result = calculator.calculate_split(participants_data, receipt_data, "proportional")

    print("Results:")
    for p in result["participants"]:
        print(f"\n{p['name']}:")
        print(f"  Items subtotal: ${p['items_subtotal']:.2f}")
        print(f"  Tax share: ${p['tax_share']:.2f}")
        print(f"  Tip share: ${p['tip_share']:.2f}")
        print(f"  FINAL TOTAL: ${p['final_total']:.2f}")

    print(f"\n\nReceipt total: ${receipt_data['total']:.2f}")
    print(f"Calculated total: ${result['summary']['total_calculated']:.2f}")
    print(f"Difference: ${abs(receipt_data['total'] - result['summary']['total_calculated']):.2f}")
