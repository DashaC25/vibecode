"""Participant and order models for tracking who ordered what."""

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from src.models.database import Base

if TYPE_CHECKING:
    from src.models.bill_session import BillSession
    from src.models.bill_split import ItemMatch, ParticipantSplit
    from src.models.receipt import ReceiptItem


class Participant(Base):
    """Represents a person participating in bill splitting."""

    __tablename__ = "participants"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("bill_sessions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Participant details
    name: Mapped[str] = mapped_column(String(100), nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    # Relationships
    session: Mapped["BillSession"] = relationship("BillSession", back_populates="participants")
    orders: Mapped[list["ParticipantOrder"]] = relationship(
        "ParticipantOrder",
        back_populates="participant",
        cascade="all, delete-orphan",
    )
    splits: Mapped[list["ParticipantSplit"]] = relationship(
        "ParticipantSplit",
        back_populates="participant",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        """String representation of the participant."""
        return f"<Participant(id={self.id}, name={self.name})>"


class ParticipantOrder(Base):
    """Represents what a participant ordered (links participants to receipt items)."""

    __tablename__ = "participant_orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    participant_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("participants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    receipt_item_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("receipt_items.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # How much of this item the participant is responsible for
    # For shared items, this can be a fraction (e.g., 0.5 for half)
    quantity_share: Mapped[float] = mapped_column(Float, nullable=False, default=1.0)

    # Optional notes about this order
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    # Relationships
    participant: Mapped["Participant"] = relationship("Participant", back_populates="orders")
    receipt_item: Mapped["ReceiptItem"] = relationship("ReceiptItem", back_populates="participant_orders")
    item_matches: Mapped[list["ItemMatch"]] = relationship(
        "ItemMatch",
        back_populates="participant_order",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        """String representation of the order."""
        return f"<ParticipantOrder(participant_id={self.participant_id}, item_id={self.receipt_item_id}, qty={self.quantity_share})>"


class VoiceTranscription(Base):
    """Stores voice transcriptions from users."""

    __tablename__ = "voice_transcriptions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("bill_sessions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Telegram file details
    telegram_file_id: Mapped[str] = mapped_column(String(255), nullable=False)

    # Transcription
    transcription_text: Mapped[str] = mapped_column(Text, nullable=False)

    # Raw extraction result (JSON string with participants and their orders)
    extracted_data: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    # Relationships
    session: Mapped["BillSession"] = relationship("BillSession", back_populates="voice_transcriptions")

    def __repr__(self) -> str:
        """String representation of the transcription."""
        return f"<VoiceTranscription(id={self.id}, session_id={self.session_id})>"
