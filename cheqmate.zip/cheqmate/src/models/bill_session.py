"""Bill session model for tracking conversation state."""

import enum
from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import BigInteger, DateTime, Enum, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from src.models.database import Base

if TYPE_CHECKING:
    from src.models.bill_split import BillSplit
    from src.models.participant import Participant, VoiceTranscription
    from src.models.receipt import Receipt


class SessionState(str, enum.Enum):
    """States for a bill splitting session."""

    WAITING_FOR_RECEIPT = "waiting_for_receipt"
    WAITING_FOR_DESCRIPTION = "waiting_for_description"
    AWAITING_CONFIRMATION = "awaiting_confirmation"
    SPLITTING_COMPLETE = "splitting_complete"
    EXPORTED = "exported"


class BillSession(Base):
    """Represents a bill-splitting session."""

    __tablename__ = "bill_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    state: Mapped[SessionState] = mapped_column(
        Enum(SessionState),
        nullable=False,
        default=SessionState.WAITING_FOR_RECEIPT,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )

    # Relationships
    receipt: Mapped["Receipt"] = relationship("Receipt", back_populates="session", uselist=False)
    participants: Mapped[list["Participant"]] = relationship(
        "Participant",
        back_populates="session",
        cascade="all, delete-orphan",
    )
    voice_transcriptions: Mapped[list["VoiceTranscription"]] = relationship(
        "VoiceTranscription",
        back_populates="session",
        cascade="all, delete-orphan",
    )
    bill_splits: Mapped[list["BillSplit"]] = relationship(
        "BillSplit",
        back_populates="session",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        """String representation of the session."""
        return f"<BillSession(id={self.id}, user_id={self.user_id}, state={self.state.value})>"
