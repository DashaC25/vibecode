"""Receipt models for storing OCR results."""

from datetime import date, datetime
from typing import TYPE_CHECKING

from sqlalchemy import Date, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from src.models.database import Base

if TYPE_CHECKING:
    from src.models.bill_session import BillSession
    from src.models.participant import ParticipantOrder


class Receipt(Base):
    """Represents a scanned receipt."""

    __tablename__ = "receipts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("bill_sessions.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
        index=True,
    )

    # Restaurant metadata
    restaurant_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    receipt_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    # Financial totals
    subtotal: Mapped[float | None] = mapped_column(Float, nullable=True)
    tax: Mapped[float | None] = mapped_column(Float, nullable=True)
    tip: Mapped[float | None] = mapped_column(Float, nullable=True)
    total: Mapped[float] = mapped_column(Float, nullable=False)

    # Raw OCR text for reference
    raw_text: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    # Relationships
    session: Mapped["BillSession"] = relationship("BillSession", back_populates="receipt")
    items: Mapped[list["ReceiptItem"]] = relationship(
        "ReceiptItem",
        back_populates="receipt",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        """String representation of the receipt."""
        return f"<Receipt(id={self.id}, total={self.total}, items={len(self.items)})>"


class ReceiptItem(Base):
    """Represents a single line item from a receipt."""

    __tablename__ = "receipt_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    receipt_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("receipts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Item details
    item_name: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    unit_price: Mapped[float] = mapped_column(Float, nullable=False)
    total_price: Mapped[float] = mapped_column(Float, nullable=False)

    # Relationships
    receipt: Mapped["Receipt"] = relationship("Receipt", back_populates="items")
    participant_orders: Mapped[list["ParticipantOrder"]] = relationship(
        "ParticipantOrder",
        back_populates="receipt_item",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        """String representation of the item."""
        return f"<ReceiptItem(name={self.item_name}, qty={self.quantity}, price={self.total_price})>"
