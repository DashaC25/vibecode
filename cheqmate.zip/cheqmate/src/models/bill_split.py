"""Bill split calculation models."""

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from src.models.database import Base

if TYPE_CHECKING:
    from src.models.bill_session import BillSession
    from src.models.participant import Participant, ParticipantOrder


class BillSplit(Base):
    """Stores the final bill split calculations for a session."""

    __tablename__ = "bill_splits"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("bill_sessions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Split metadata
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # Tax/tip distribution strategy
    distribution_method: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="proportional",  # or "equal", "custom"
    )

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    # Relationships
    session: Mapped["BillSession"] = relationship("BillSession", back_populates="bill_splits")
    participant_splits: Mapped[list["ParticipantSplit"]] = relationship(
        "ParticipantSplit",
        back_populates="bill_split",
        cascade="all, delete-orphan",
    )
    item_matches: Mapped[list["ItemMatch"]] = relationship(
        "ItemMatch",
        back_populates="bill_split",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        """String representation of the bill split."""
        return f"<BillSplit(id={self.id}, session_id={self.session_id}, version={self.version})>"


class ParticipantSplit(Base):
    """Stores final calculated amounts for each participant in a split."""

    __tablename__ = "participant_splits"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    bill_split_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("bill_splits.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    participant_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("participants.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Financial breakdown
    items_subtotal: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    tax_share: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    tip_share: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    final_total: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)

    # Optional adjustments
    manual_adjustment: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    adjustment_notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    # User confirmation
    confirmed_by_user: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    # Relationships
    bill_split: Mapped["BillSplit"] = relationship("BillSplit", back_populates="participant_splits")
    participant: Mapped["Participant"] = relationship("Participant", back_populates="splits")

    def __repr__(self) -> str:
        """String representation of the participant split."""
        return f"<ParticipantSplit(id={self.id}, participant_id={self.participant_id}, total={self.final_total})>"


class ItemMatch(Base):
    """Stores the matching between voice order descriptions and receipt items."""

    __tablename__ = "item_matches"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    bill_split_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("bill_splits.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    participant_order_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("participant_orders.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Matching details
    user_description: Mapped[str] = mapped_column(String(255), nullable=False)
    receipt_item_name: Mapped[str] = mapped_column(String(255), nullable=False)

    # Confidence and method
    match_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)  # 0.0 to 1.0
    match_method: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="ai",  # or "fuzzy", "exact", "manual"
    )

    # Quantity allocation
    allocated_quantity: Mapped[float] = mapped_column(Float, nullable=False, default=1.0)

    # User validation
    user_confirmed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    user_corrected: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    correction_notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    # Relationships
    bill_split: Mapped["BillSplit"] = relationship("BillSplit", back_populates="item_matches")
    participant_order: Mapped["ParticipantOrder"] = relationship(
        "ParticipantOrder",
        back_populates="item_matches",
    )

    def __repr__(self) -> str:
        """String representation of the item match."""
        return f"<ItemMatch(id={self.id}, confidence={self.match_confidence}, method={self.match_method})>"
