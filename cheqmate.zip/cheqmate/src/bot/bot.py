"""Telegram bot initialization and handlers."""

import logging
from datetime import datetime
from typing import Final

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

from src.config import settings
from src.models.bill_session import BillSession, SessionState
from src.models.bill_split import BillSplit, ItemMatch, ParticipantSplit
from src.models.database import get_db_session
from src.models.participant import Participant, ParticipantOrder
from src.models.receipt import Receipt, ReceiptItem
from src.processors import MatchingProcessor, ReceiptProcessor, SplitCalculator

logger = logging.getLogger(__name__)

# Bot capabilities message
CAPABILITIES_MESSAGE: Final[str] = """
👋 **Welcome to CheqMate!**

I'm your smart restaurant bill-splitting assistant. Here's what I can do:

📸 **Receipt Scanning**
Take a photo of your receipt, and I'll extract all the items, prices, and totals using AI-powered OCR.

💬 **Smart Matching**
Tell me who ordered what in plain text, and I'll automatically match dishes to people using AI.

💰 **Fair Splitting**
I'll calculate each person's share, including their portion of tax and tip, so everyone pays their fair amount.

📤 **Export to Apps**
Push the split directly to Splitwise or Tricount to settle up with your friends (coming soon).

---

**How to use:**
1. Type /newbill to start
2. Send a photo of the receipt
3. Tell me who ordered what (e.g., "I had the burger, Sarah had the salad")
4. Review and confirm the split
5. Done!

Ready to split some bills? Let's get started!

Type /help anytime to see this message again.
"""


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /start command."""
    if update.effective_user and update.message:
        user = update.effective_user
        logger.info(f"User {user.id} ({user.username}) started the bot")
        await update.message.reply_text(
            CAPABILITIES_MESSAGE,
            parse_mode="Markdown",
        )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /help command."""
    if update.message:
        logger.info("Help command received")
        await update.message.reply_text(
            CAPABILITIES_MESSAGE,
            parse_mode="Markdown",
        )


async def newbill_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle the /newbill command - start a new bill splitting session."""
    if not update.effective_user or not update.message:
        return

    user = update.effective_user
    chat_id = update.message.chat_id

    logger.info(f"User {user.id} ({user.username}) started new bill in chat {chat_id}")

    try:
        with get_db_session() as db:
            # Check if user already has an active session
            existing_session = (
                db.query(BillSession)
                .filter(
                    BillSession.user_id == user.id,
                    BillSession.chat_id == chat_id,
                    BillSession.state.in_(
                        [
                            SessionState.WAITING_FOR_RECEIPT,
                            SessionState.WAITING_FOR_DESCRIPTION,
                            SessionState.AWAITING_CONFIRMATION,
                        ]
                    ),
                )
                .first()
            )

            if existing_session:
                session = existing_session
                logger.info(f"Reusing existing session {session.id} for user {user.id}")
                message = "You already have an active bill session. Please send me a photo of your receipt 📸"
            else:
                # Create new session
                session = BillSession(
                    user_id=user.id,
                    chat_id=chat_id,
                    state=SessionState.WAITING_FOR_RECEIPT,
                )
                db.add(session)
                db.flush()

                logger.info(f"Created new bill session {session.id} for user {user.id}")
                message = "Great! Let's split a new bill. Please send me a photo of your receipt 📸"

            context.user_data["current_session_id"] = session.id

        await update.message.reply_text(message)

    except Exception as e:
        logger.error(f"Error creating bill session: {e}", exc_info=True)
        await update.message.reply_text(
            "Sorry, I encountered an error starting a new bill session. Please try again later."
        )


async def photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle photo messages - process receipt images."""
    if not update.effective_user or not update.message or not update.message.photo:
        return

    user = update.effective_user
    chat_id = update.message.chat_id

    logger.info(f"Received photo from user {user.id} in chat {chat_id}")

    try:
        with get_db_session() as db:
            session = (
                db.query(BillSession)
                .filter(
                    BillSession.user_id == user.id,
                    BillSession.chat_id == chat_id,
                    BillSession.state == SessionState.WAITING_FOR_RECEIPT,
                )
                .first()
            )

            if not session:
                await update.message.reply_text("Please start a new bill first using /newbill command.")
                return

            processing_msg = await update.message.reply_text(
                "Processing your receipt... 🔍\nThis may take a few seconds."
            )

            try:
                # Get the largest photo (best quality)
                photo = update.message.photo[-1]
                photo_file = await photo.get_file()
                photo_bytes = await photo_file.download_as_bytearray()
                photo_bytes_io = bytes(photo_bytes)

                logger.info(f"Downloaded photo: {len(photo_bytes_io)} bytes")

                # Process receipt with Anthropic
                processor = ReceiptProcessor()
                receipt_data = await processor.process_receipt_image(photo_bytes_io)

                # Save receipt to database
                receipt = Receipt(
                    session_id=session.id,
                    restaurant_name=receipt_data.get("restaurant_name"),
                    receipt_date=datetime.strptime(receipt_data["receipt_date"], "%Y-%m-%d").date()
                    if receipt_data.get("receipt_date")
                    else None,
                    subtotal=receipt_data.get("subtotal"),
                    tax=receipt_data.get("tax"),
                    tip=receipt_data.get("tip"),
                    total=receipt_data["total"],
                    raw_text=receipt_data.get("raw_text"),
                )
                db.add(receipt)
                db.flush()

                # Save receipt items
                for item_data in receipt_data.get("items", []):
                    item = ReceiptItem(
                        receipt_id=receipt.id,
                        item_name=item_data["name"],
                        quantity=item_data.get("quantity", 1),
                        unit_price=item_data["unit_price"],
                        total_price=item_data["total_price"],
                    )
                    db.add(item)

                # Update session state to waiting for description
                session.state = SessionState.WAITING_FOR_DESCRIPTION

                logger.info(f"Saved receipt {receipt.id} with {len(receipt_data['items'])} items")

                # Delete processing message
                await processing_msg.delete()

                # Send formatted receipt message
                formatted_message = processor.format_receipt_message(receipt_data)
                await update.message.reply_text(formatted_message, parse_mode="Markdown")

                # Ask for description
                description_prompt = (
                    "\n📝 **Next Step:**\n\n"
                    "Please tell me who ordered what!\n\n"
                    "Just send a message describing the order. For example:\n"
                    "• _'I had the burger, Sarah had the salad'_\n"
                    "• _'Me and John split the pizza, Sarah had the pasta'_\n"
                    "• _'I ordered the steak, fries were shared by everyone'_\n\n"
                    "I'll match your description to the receipt items automatically!"
                )
                await update.message.reply_text(description_prompt, parse_mode="Markdown")

            except ValueError as e:
                logger.error(f"Receipt processing validation error: {e}")
                await processing_msg.edit_text(
                    f"Sorry, I couldn't process this receipt: {e}\n\n"
                    "Please make sure the photo is clear and shows the entire receipt."
                )
            except Exception as e:
                logger.error(f"Error processing receipt: {e}", exc_info=True)
                await processing_msg.edit_text(
                    "Sorry, I encountered an error processing your receipt. "
                    "Please try again with a clearer photo."
                )

    except Exception as e:
        logger.error(f"Error in photo handler: {e}", exc_info=True)
        await update.message.reply_text(
            "Sorry, I encountered an unexpected error. Please try again later."
        )


async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text messages - match items or process confirmations."""
    if not update.effective_user or not update.message or not update.message.text:
        return

    user = update.effective_user
    chat_id = update.message.chat_id
    text = update.message.text.strip()

    # Ignore commands
    if text.startswith("/"):
        return

    logger.info(f"Received text from user {user.id}: {text[:50]}...")

    try:
        with get_db_session() as db:
            session = (
                db.query(BillSession)
                .filter(
                    BillSession.user_id == user.id,
                    BillSession.chat_id == chat_id,
                    BillSession.state.in_(
                        [SessionState.WAITING_FOR_DESCRIPTION, SessionState.AWAITING_CONFIRMATION]
                    ),
                )
                .first()
            )

            if not session:
                logger.info(f"No active session for user {user.id}, ignoring text")
                return

            # Handle confirmation responses
            if session.state == SessionState.AWAITING_CONFIRMATION:
                await handle_confirmation(update, context, session, text, db)
                return

            # Handle description matching
            if session.state == SessionState.WAITING_FOR_DESCRIPTION:
                await handle_description(update, context, session, text, db)
                return

    except Exception as e:
        logger.error(f"Error in text handler: {e}", exc_info=True)
        await update.message.reply_text(
            "Sorry, I encountered an unexpected error. Please try again later."
        )


async def handle_description(update, context, session, text, db) -> None:
    """Handle user description of who ordered what."""
    receipt = session.receipt
    if not receipt:
        await update.message.reply_text("I couldn't find your receipt. Please start over with /newbill.")
        return

    processing_msg = await update.message.reply_text("Matching items to people... 🎯")

    try:
        # Prepare receipt items for matching
        receipt_items = [
            {
                "id": item.id,
                "name": item.item_name,
                "price": item.total_price,
                "unit_price": item.unit_price,
                "quantity": item.quantity,
            }
            for item in receipt.items
        ]

        # Match items using AI
        matcher = MatchingProcessor()
        matching_result = await matcher.match_items(text, receipt_items)

        # Store matching results in context for confirmation
        context.user_data["matching_result"] = matching_result
        context.user_data["user_description"] = text

        # Delete processing message
        await processing_msg.delete()

        # Show matching results
        formatted_message = matcher.format_matching_results(matching_result)
        await update.message.reply_text(formatted_message, parse_mode="Markdown")

        # Update session state
        session.state = SessionState.AWAITING_CONFIRMATION

        logger.info(f"Item matching complete for session {session.id}")

    except Exception as e:
        logger.error(f"Error matching items: {e}", exc_info=True)
        await processing_msg.edit_text(
            "Sorry, I encountered an error matching items. Please try describing the order again."
        )


async def handle_confirmation(update, context, session, text, db) -> None:
    """Handle user confirmation of matching results."""
    text_lower = text.lower()

    # Check for confirmation
    if text_lower in ["yes", "y", "correct", "ok", "confirm", "looks good", "👍"]:
        await calculate_and_display_split(update, context, session, db)
    elif text_lower in ["no", "n", "edit", "wrong", "incorrect", "fix"]:
        # Ask for new description
        await update.message.reply_text(
            "No problem! Please send a new description of who ordered what, and I'll try again."
        )
        session.state = SessionState.WAITING_FOR_DESCRIPTION
    else:
        # Treat as new description
        await handle_description(update, context, session, text, db)


async def calculate_and_display_split(update, context, session, db) -> None:
    """Calculate the bill split and display results."""
    calculating_msg = await update.message.reply_text("Calculating split... 💰")

    try:
        matching_result = context.user_data.get("matching_result")
        if not matching_result:
            await calculating_msg.edit_text(
                "Sorry, I lost the matching data. Please start over by describing who ordered what."
            )
            session.state = SessionState.WAITING_FOR_DESCRIPTION
            return

        receipt = session.receipt
        if not receipt:
            await calculating_msg.edit_text("Receipt not found. Please start over with /newbill.")
            return

        # Create participants and orders in database
        participant_map = {}
        for participant_data in matching_result.get("participants", []):
            participant = Participant(
                session_id=session.id,
                name=participant_data["name"],
            )
            db.add(participant)
            db.flush()
            participant_map[participant_data["name"]] = participant

            # Create participant orders
            for order in participant_data.get("orders", []):
                participant_order = ParticipantOrder(
                    participant_id=participant.id,
                    receipt_item_id=order["receipt_item_id"],
                    quantity_share=order.get("quantity_share", 1.0),
                    notes=order.get("matching_notes"),
                )
                db.add(participant_order)

        db.flush()

        # Prepare data for split calculation
        participants_for_calc = []
        for participant_data in matching_result.get("participants", []):
            participant = participant_map[participant_data["name"]]
            participants_for_calc.append(
                {
                    "name": participant.name,
                    "participant_id": participant.id,
                    "orders": participant_data.get("orders", []),
                }
            )

        receipt_data = {
            "subtotal": receipt.subtotal or receipt.total,
            "tax": receipt.tax or 0.0,
            "tip": receipt.tip or 0.0,
            "total": receipt.total,
        }

        # Calculate split
        calculator = SplitCalculator()
        split_result = calculator.calculate_split(participants_for_calc, receipt_data, "proportional")

        # Save split to database
        bill_split = BillSplit(
            session_id=session.id,
            version=1,
            is_active=True,
            distribution_method="proportional",
        )
        db.add(bill_split)
        db.flush()

        # Save participant splits
        for split_data in split_result["participants"]:
            logger.info(
                f"Creating ParticipantSplit for {split_data['name']}: "
                f"items_subtotal={split_data['items_subtotal']}, "
                f"tax_share={split_data['tax_share']}, "
                f"tip_share={split_data['tip_share']}, "
                f"final_total={split_data['final_total']}"
            )
            participant_split = ParticipantSplit(
                bill_split_id=bill_split.id,
                participant_id=split_data["participant_id"],
                items_subtotal=split_data["items_subtotal"],
                tax_share=split_data["tax_share"],
                tip_share=split_data["tip_share"],
                final_total=split_data["final_total"],
                confirmed_by_user=True,
            )
            db.add(participant_split)
            logger.info(
                f"Added ParticipantSplit to session: "
                f"items_subtotal={participant_split.items_subtotal}, "
                f"tax_share={participant_split.tax_share}, "
                f"tip_share={participant_split.tip_share}, "
                f"final_total={participant_split.final_total}"
            )

        # Update session state
        session.state = SessionState.SPLITTING_COMPLETE

        logger.info(f"Split calculation complete for session {session.id}")

        # Delete calculating message
        await calculating_msg.delete()

        # Display split results
        formatted_split = calculator.format_split_results(split_result)
        await update.message.reply_text(formatted_split, parse_mode="Markdown")

        # Offer detailed breakdown
        await update.message.reply_text(
            "💡 **Tip:** Send /details to see a detailed breakdown of the calculations.\n\n"
            "Ready for another bill? Just send /newbill to start over!"
        )

    except Exception as e:
        logger.error(f"Error calculating split: {e}", exc_info=True)
        await calculating_msg.edit_text(
            "Sorry, I encountered an error calculating the split. Please try again or start over with /newbill."
        )


async def details_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show detailed breakdown of the split."""
    if not update.effective_user or not update.message:
        return

    user = update.effective_user
    chat_id = update.message.chat_id

    try:
        with get_db_session() as db:
            # Get most recent completed split
            session = (
                db.query(BillSession)
                .filter(
                    BillSession.user_id == user.id,
                    BillSession.chat_id == chat_id,
                    BillSession.state == SessionState.SPLITTING_COMPLETE,
                )
                .order_by(BillSession.updated_at.desc())
                .first()
            )

            if not session or not session.bill_splits:
                await update.message.reply_text(
                    "No completed split found. Please complete a bill split first using /newbill."
                )
                return

            # Get the active split
            bill_split = next((s for s in session.bill_splits if s.is_active), None)
            if not bill_split:
                await update.message.reply_text("No active split found.")
                return

            # Reconstruct split result for formatting
            split_result = {
                "participants": [],
                "receipt_total": session.receipt.total,
                "distribution_method": bill_split.distribution_method,
                "summary": {"total_calculated": 0.0},
            }

            for participant_split in bill_split.participant_splits:
                participant = participant_split.participant
                split_result["participants"].append(
                    {
                        "name": participant.name,
                        "items_subtotal": participant_split.items_subtotal,
                        "tax_share": participant_split.tax_share,
                        "tip_share": participant_split.tip_share,
                        "final_total": participant_split.final_total,
                        "items": [
                            {
                                "name": order.receipt_item.item_name,
                                "unit_price": order.receipt_item.unit_price,
                                "quantity_share": order.quantity_share,
                                "item_total": order.receipt_item.unit_price * order.quantity_share,
                            }
                            for order in participant.orders
                        ],
                    }
                )
                split_result["summary"]["total_calculated"] += participant_split.final_total

            # Format and send detailed breakdown
            calculator = SplitCalculator()
            detailed_message = calculator.format_detailed_breakdown(split_result)
            await update.message.reply_text(detailed_message, parse_mode="Markdown")

    except Exception as e:
        logger.error(f"Error showing details: {e}", exc_info=True)
        await update.message.reply_text("Sorry, I couldn't retrieve the split details.")


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle errors in the bot."""
    logger.error(f"Exception while handling an update: {context.error}", exc_info=context.error)


def create_bot() -> Application:
    """Create and configure the Telegram bot application."""
    application = Application.builder().token(settings.telegram_bot_token).build()

    # Register command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("newbill", newbill_command))
    application.add_handler(CommandHandler("details", details_command))

    # Register message handlers
    application.add_handler(MessageHandler(filters.PHOTO, photo_handler))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))

    # Register error handler
    application.add_error_handler(error_handler)

    logger.info("Bot application created and handlers registered")
    return application


def run_bot() -> None:
    """Run the bot. This function will block until the bot is stopped."""
    logger.info("Starting CheqMate bot...")

    application = create_bot()

    logger.info("Bot is now running. Press Ctrl+C to stop.")
    application.run_polling(allowed_updates=Update.ALL_TYPES)
