"""Receipt OCR processing using Anthropic Claude Vision API."""

import base64
import json
import logging
from datetime import date
from typing import Any

import anthropic

from src.config import settings

logger = logging.getLogger(__name__)


class ReceiptProcessor:
    """Process receipt images using Anthropic Claude Vision API."""

    def __init__(self) -> None:
        """Initialize the receipt processor."""
        if not settings.anthropic_api_key:
            raise ValueError("ANTHROPIC_API_KEY is not configured in settings")

        self.client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    async def process_receipt_image(self, image_bytes: bytes, image_format: str = "image/jpeg") -> dict[str, Any]:
        """Process a receipt image and extract structured data.

        Args:
            image_bytes: Raw image bytes
            image_format: MIME type of the image (default: image/jpeg)

        Returns:
            Dictionary containing:
                - items: List of {name, quantity, unit_price, total_price}
                - restaurant_name: Optional restaurant name
                - receipt_date: Optional date string (YYYY-MM-DD)
                - subtotal: Optional float
                - tax: Optional float
                - tip: Optional float
                - total: Required float
                - raw_text: Original extracted text

        Raises:
            Exception: If OCR processing fails
        """
        logger.info("Processing receipt image with Anthropic Claude Vision API")

        # Convert image to base64
        image_base64 = base64.b64encode(image_bytes).decode("utf-8")

        try:
            # Call Anthropic API with vision prompt
            response = self.client.messages.create(
                model="claude-sonnet-4-5-20250929",
                max_tokens=2000,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": image_format,
                                    "data": image_base64,
                                },
                            },
                            {
                                "type": "text",
                                "text": self._get_ocr_prompt(),
                            },
                        ],
                    }
                ],
            )

            # Extract the response text
            if not response.content or len(response.content) == 0:
                logger.error(f"Empty response from Claude API. Full response: {response}")
                raise ValueError("Received empty response from OCR service")

            response_text = response.content[0].text
            logger.info(f"Claude raw response (first 500 chars): {response_text[:500]}")

            # Check if response is empty
            if not response_text or not response_text.strip():
                logger.error("Response text is empty or whitespace only")
                raise ValueError("Received empty text from OCR service")

            # Strip markdown code blocks if present (e.g., ```json ... ```)
            response_text = response_text.strip()
            if response_text.startswith("```"):
                logger.info("Detected markdown code block, stripping...")
                # Remove opening ```json or ``` and closing ```
                lines = response_text.split("\n")
                if lines[0].startswith("```"):
                    lines = lines[1:]  # Remove first line
                if lines and lines[-1].strip() == "```":
                    lines = lines[:-1]  # Remove last line
                response_text = "\n".join(lines).strip()
                logger.info(f"Stripped response (first 200 chars): {response_text[:200]}")

            # Parse the JSON response
            receipt_data = json.loads(response_text)

            # Validate required fields
            if "total" not in receipt_data:
                raise ValueError("Receipt total is required but was not extracted")

            if "items" not in receipt_data or not receipt_data["items"]:
                raise ValueError("No items were extracted from the receipt")

            logger.info(f"Successfully extracted {len(receipt_data['items'])} items from receipt")
            return receipt_data

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse Claude response as JSON: {e}")
            logger.error(f"Response text that failed to parse (first 1000 chars): {response_text[:1000]}")
            raise Exception(f"Failed to parse receipt data from OCR response. Error: {e}") from e
        except anthropic.APIError as e:
            logger.error(f"Anthropic API error: {e}")
            raise Exception(f"OCR service error: {e}") from e
        except Exception as e:
            logger.error(f"Unexpected error during receipt processing: {e}")
            raise

    def _get_ocr_prompt(self) -> str:
        """Get the prompt for receipt OCR."""
        return """You are a receipt OCR system. Analyze this receipt image and extract ALL information in valid JSON format.

**CRITICAL**: Return ONLY valid JSON, no markdown, no explanation, no code blocks. Just pure JSON.

Extract the following information:

{
  "restaurant_name": "Name of the restaurant (string or null)",
  "receipt_date": "Date in YYYY-MM-DD format (string or null)",
  "items": [
    {
      "name": "Item name (string, required)",
      "quantity": 1,
      "unit_price": 10.50,
      "total_price": 10.50
    }
  ],
  "subtotal": 50.00,
  "tax": 5.00,
  "tip": 10.00,
  "total": 65.00,
  "raw_text": "Full text transcription of the receipt"
}

**Rules:**
1. Extract ALL line items with their names, quantities, and prices
2. If quantity is not shown, assume 1
3. For items with quantity (e.g., "2x Beer"), parse the quantity
4. Calculate total_price = quantity * unit_price for each item
5. Extract subtotal, tax, tip, and total if visible
6. Extract restaurant name and date if visible
7. Set fields to null if not found
8. Return ONLY valid JSON, nothing else

Remember: ONLY JSON output, no markdown formatting!"""

    def format_receipt_message(self, receipt_data: dict[str, Any]) -> str:
        """Format receipt data as a user-friendly message.

        Args:
            receipt_data: Parsed receipt data from process_receipt_image()

        Returns:
            Formatted message string for Telegram
        """
        lines = ["📋 **Receipt Processed Successfully!**\n"]

        # Restaurant and date
        if receipt_data.get("restaurant_name"):
            lines.append(f"🏪 **{receipt_data['restaurant_name']}**")
        if receipt_data.get("receipt_date"):
            lines.append(f"📅 {receipt_data['receipt_date']}")

        if receipt_data.get("restaurant_name") or receipt_data.get("receipt_date"):
            lines.append("")

        # Items
        lines.append("**Items:**")
        for item in receipt_data.get("items", []):
            qty = item.get("quantity", 1)
            name = item.get("name", "Unknown")
            unit_price = item.get("unit_price", 0)
            total_price = item.get("total_price", 0)

            if qty > 1:
                lines.append(f"• {qty}x {name} @ ${unit_price:.2f} = ${total_price:.2f}")
            else:
                lines.append(f"• {name} - ${total_price:.2f}")

        # Financial summary
        lines.append("\n**Summary:**")
        if receipt_data.get("subtotal") is not None:
            lines.append(f"Subtotal: ${receipt_data['subtotal']:.2f}")
        if receipt_data.get("tax") is not None:
            lines.append(f"Tax: ${receipt_data['tax']:.2f}")
        if receipt_data.get("tip") is not None:
            lines.append(f"Tip: ${receipt_data['tip']:.2f}")

        total = receipt_data.get("total", 0)
        lines.append(f"**Total: ${total:.2f}**")

        return "\n".join(lines)
