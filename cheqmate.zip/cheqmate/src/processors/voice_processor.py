"""Voice transcription and participant extraction using OpenAI Whisper and GPT."""

import io
import json
import logging
from typing import Any

import anthropic
from openai import AsyncOpenAI

from src.config import settings

logger = logging.getLogger(__name__)


class VoiceProcessor:
    """Process voice notes to transcribe and extract participant orders."""

    def __init__(self) -> None:
        """Initialize the voice processor."""
        if not settings.openai_api_key:
            raise ValueError("OPENAI_API_KEY is not configured in settings")

        self.openai_client = AsyncOpenAI(api_key=settings.openai_api_key)

        # Use Anthropic for participant extraction if available, otherwise OpenAI
        self.use_anthropic = bool(settings.anthropic_api_key)
        if self.use_anthropic:
            self.anthropic_client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    async def transcribe_voice(self, audio_bytes: bytes, audio_format: str = "ogg") -> str:
        """Transcribe voice audio using OpenAI Whisper.

        Args:
            audio_bytes: Raw audio bytes
            audio_format: Audio format (e.g., 'ogg', 'mp3', 'wav')

        Returns:
            Transcribed text

        Raises:
            Exception: If transcription fails
        """
        logger.info(f"Transcribing voice note ({len(audio_bytes)} bytes, format: {audio_format})")

        try:
            # Create a file-like object from bytes
            audio_file = io.BytesIO(audio_bytes)
            audio_file.name = f"voice.{audio_format}"

            # Call OpenAI Whisper API
            response = await self.openai_client.audio.transcriptions.create(
                model="whisper-1",
                file=audio_file,
                response_format="text",
            )

            transcription = response.strip() if isinstance(response, str) else response.text.strip()
            logger.info(f"Transcription successful: {transcription[:100]}...")
            return transcription

        except Exception as e:
            logger.error(f"Error transcribing voice: {e}", exc_info=True)
            raise Exception(f"Failed to transcribe voice note: {e}") from e

    async def extract_participants_from_text(
        self, text: str, receipt_items: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Extract participant names and their orders from transcribed text.

        Args:
            text: Transcribed text or user-provided text
            receipt_items: List of receipt items with names (for context)

        Returns:
            Dictionary containing:
                - participants: List of {name: str, items: list[str]}
                - raw_text: Original text
                - extraction_notes: Optional notes about the extraction

        Raises:
            Exception: If extraction fails
        """
        logger.info(f"Extracting participants from text: {text[:100]}...")

        # Format receipt items for context
        receipt_context = "\n".join(
            [f"- {item['name']} (${item['total_price']:.2f})" for item in receipt_items]
        )

        if self.use_anthropic:
            return await self._extract_with_anthropic(text, receipt_context)
        else:
            return await self._extract_with_openai(text, receipt_context)

    async def _extract_with_anthropic(self, text: str, receipt_context: str) -> dict[str, Any]:
        """Extract participants using Anthropic Claude."""
        logger.info("Extracting participants with Anthropic Claude")

        try:
            response = self.anthropic_client.messages.create(
                model="claude-sonnet-4-5-20250929",
                max_tokens=1500,
                messages=[
                    {
                        "role": "user",
                        "content": self._get_extraction_prompt(text, receipt_context),
                    }
                ],
            )

            response_text = response.content[0].text.strip()
            logger.info(f"Claude extraction response: {response_text[:200]}")

            # Strip markdown code blocks if present
            if response_text.startswith("```"):
                lines = response_text.split("\n")
                if lines[0].startswith("```"):
                    lines = lines[1:]
                if lines and lines[-1].strip() == "```":
                    lines = lines[:-1]
                response_text = "\n".join(lines).strip()

            result = json.loads(response_text)
            logger.info(f"Successfully extracted {len(result.get('participants', []))} participants")
            return result

        except Exception as e:
            logger.error(f"Error extracting with Anthropic: {e}", exc_info=True)
            raise Exception(f"Failed to extract participants: {e}") from e

    async def _extract_with_openai(self, text: str, receipt_context: str) -> dict[str, Any]:
        """Extract participants using OpenAI GPT."""
        logger.info("Extracting participants with OpenAI GPT")

        try:
            response = await self.openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": "You are an assistant that extracts participant names and their orders from text. Always respond with valid JSON only.",
                    },
                    {
                        "role": "user",
                        "content": self._get_extraction_prompt(text, receipt_context),
                    },
                ],
                temperature=0.3,
            )

            response_text = response.choices[0].message.content.strip()
            logger.info(f"GPT extraction response: {response_text[:200]}")

            # Strip markdown code blocks if present
            if response_text.startswith("```"):
                lines = response_text.split("\n")
                if lines[0].startswith("```"):
                    lines = lines[1:]
                if lines and lines[-1].strip() == "```":
                    lines = lines[:-1]
                response_text = "\n".join(lines).strip()

            result = json.loads(response_text)
            logger.info(f"Successfully extracted {len(result.get('participants', []))} participants")
            return result

        except Exception as e:
            logger.error(f"Error extracting with OpenAI: {e}", exc_info=True)
            raise Exception(f"Failed to extract participants: {e}") from e

    def _get_extraction_prompt(self, text: str, receipt_context: str) -> str:
        """Get the prompt for participant extraction."""
        return f"""Analyze the following text where someone describes who ordered what at a restaurant.

**Receipt Items:**
{receipt_context}

**User's description:**
{text}

Extract ALL participants mentioned and what items they ordered. Match the mentioned items to the receipt items using fuzzy matching (e.g., "burger" matches "Classic Burger").

Return ONLY valid JSON in this exact format (no markdown, no explanation):

{{
  "participants": [
    {{
      "name": "Person Name",
      "items": ["Item name from receipt", "Another item"]
    }}
  ],
  "extraction_notes": "Optional notes about ambiguities or assumptions made"
}}

**Rules:**
1. Extract ALL participant names mentioned (e.g., "I", "Sarah", "John", "me", etc.)
2. Convert first-person pronouns ("I", "me", "my") to "You" or ask for clarification
3. Match mentioned food items to receipt items (use fuzzy matching)
4. If an item is shared (e.g., "Sarah and I split the fries"), list it for both participants
5. If unclear, note it in extraction_notes
6. Return ONLY valid JSON, nothing else

Example:
Input: "I had the burger and fries, Sarah had the salad, and we shared the dessert"
Output:
{{
  "participants": [
    {{"name": "You", "items": ["burger", "fries", "dessert"]}},
    {{"name": "Sarah", "items": ["salad", "dessert"]}}
  ],
  "extraction_notes": "Dessert is shared between You and Sarah"
}}"""

    def format_participants_message(self, extraction_result: dict[str, Any]) -> str:
        """Format extraction result as a user-friendly message.

        Args:
            extraction_result: Result from extract_participants_from_text()

        Returns:
            Formatted message string for Telegram
        """
        lines = ["👥 **Participants Identified:**\n"]

        participants = extraction_result.get("participants", [])
        if not participants:
            return "⚠️ I couldn't identify any participants from your message. Please try again."

        for participant in participants:
            name = participant.get("name", "Unknown")
            items = participant.get("items", [])

            lines.append(f"**{name}:**")
            if items:
                for item in items:
                    lines.append(f"  • {item}")
            else:
                lines.append("  • (no items specified)")
            lines.append("")

        if extraction_result.get("extraction_notes"):
            lines.append(f"📝 *Note: {extraction_result['extraction_notes']}*\n")

        lines.append("---\n")
        lines.append(
            "Is this correct? If yes, I'll proceed to match these to your receipt items. "
            "If not, please send another message to clarify."
        )

        return "\n".join(lines)
