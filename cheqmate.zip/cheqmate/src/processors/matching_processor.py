"""Item matching processor using AI and fuzzy matching."""

import json
import logging
from typing import Any

import anthropic
from thefuzz import fuzz

from src.config import settings

logger = logging.getLogger(__name__)


class MatchingProcessor:
    """Match participant descriptions to receipt items using AI and fuzzy matching."""

    def __init__(self) -> None:
        """Initialize the matching processor."""
        if not settings.anthropic_api_key:
            raise ValueError("ANTHROPIC_API_KEY is not configured in settings")

        self.client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    async def match_items(
        self, user_description: str, receipt_items: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Match user's description to receipt items using AI.

        Args:
            user_description: Text description of who ordered what
            receipt_items: List of receipt items with id, name, price, quantity

        Returns:
            Dictionary containing:
                - participants: List of matched participants with their orders
                - unmatched_items: Items from receipt not assigned to anyone
                - ambiguities: Items with low confidence matches
                - notes: General notes about the matching

        Raises:
            Exception: If matching fails
        """
        logger.info(f"Matching items for description: {user_description[:100]}...")

        # Format receipt items with IDs for AI
        receipt_context = self._format_receipt_for_prompt(receipt_items)

        try:
            # Call Anthropic API with matching prompt
            response = self.client.messages.create(
                model="claude-sonnet-4-5-20250929",
                max_tokens=2000,
                messages=[
                    {
                        "role": "user",
                        "content": self._get_matching_prompt(user_description, receipt_context),
                    }
                ],
            )

            response_text = response.content[0].text.strip()
            logger.info(f"AI matching response (first 300 chars): {response_text[:300]}")

            # Strip markdown code blocks if present
            if response_text.startswith("```"):
                lines = response_text.split("\n")
                if lines[0].startswith("```"):
                    lines = lines[1:]
                if lines and lines[-1].strip() == "```":
                    lines = lines[:-1]
                response_text = "\n".join(lines).strip()

            result = json.loads(response_text)

            # Enhance with fuzzy matching confidence scores
            result = self._enhance_with_fuzzy_scores(result, receipt_items)

            logger.info(f"Successfully matched {len(result.get('participants', []))} participants")
            return result

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse AI response as JSON: {e}")
            logger.error(f"Response text: {response_text[:500]}")
            raise Exception(f"Failed to parse matching results: {e}") from e
        except anthropic.APIError as e:
            logger.error(f"Anthropic API error: {e}")
            raise Exception(f"AI matching service error: {e}") from e
        except Exception as e:
            logger.error(f"Unexpected error during matching: {e}", exc_info=True)
            raise

    def _format_receipt_for_prompt(self, receipt_items: list[dict[str, Any]]) -> str:
        """Format receipt items for the AI prompt."""
        lines = []
        for item in receipt_items:
            item_id = item.get("id")
            name = item.get("name", "Unknown")
            price = item.get("price", 0.0)
            qty = item.get("quantity", 1)

            if qty > 1:
                lines.append(f"{item_id}. {name} - ${price:.2f} (qty: {qty})")
            else:
                lines.append(f"{item_id}. {name} - ${price:.2f}")

        return "\n".join(lines)

    def _get_matching_prompt(self, user_description: str, receipt_context: str) -> str:
        """Get the prompt for AI-based item matching."""
        return f"""You are a bill-splitting assistant. Match the user's description to actual receipt items.

**Receipt Items (with IDs):**
{receipt_context}

**User's description:**
{user_description}

**Task:**
Match participants to receipt items using fuzzy matching. Handle shared items correctly.

**Output Format (VALID JSON ONLY, no markdown):**
{{
  "participants": [
    {{
      "name": "string",
      "orders": [
        {{
          "receipt_item_id": 1,
          "receipt_item_name": "Classic Burger",
          "quantity_share": 1.0,
          "confidence": 0.95,
          "matching_notes": "Direct match: user said 'burger'"
        }}
      ]
    }}
  ],
  "unmatched_items": [
    {{
      "receipt_item_id": 4,
      "receipt_item_name": "Dessert",
      "reason": "Not mentioned by user"
    }}
  ],
  "ambiguities": [
    {{
      "participant": "Sarah",
      "mentioned_item": "burger",
      "possible_matches": [
        {{"receipt_item_id": 1, "name": "Classic Burger", "confidence": 0.8}},
        {{"receipt_item_id": 2, "name": "Veggie Burger", "confidence": 0.7}}
      ]
    }}
  ],
  "notes": "Optional overall notes"
}}

**Rules:**
1. Convert "I"/"me"/"my" to "You" as participant name
2. Use fuzzy matching: "burger" matches "Classic Burger", "Veggie Burger", etc.
3. For shared items (e.g., "we split the pizza"), divide quantity_share proportionally:
   - "2 people split pizza" → each gets 0.5
   - "3 people share fries" → each gets 0.33
   - quantity_share values must sum to the item's total quantity
4. If multiple receipt items match description, choose best match OR flag as ambiguous (confidence < 0.7)
5. Return confidence score (0-1) for each match based on how certain you are
6. Include receipt_item_id for database linking
7. List any receipt items not mentioned in unmatched_items
8. If unclear which receipt item was meant, add to ambiguities array

**Examples:**
- "I had the burger" → You gets 100% of a burger item (quantity_share: 1.0)
- "Sarah and I split the pizza" → You and Sarah each get 50% (quantity_share: 0.5 each)
- "We all shared the fries" (3 people) → Each person gets 33% (quantity_share: 0.33 each)

Return ONLY valid JSON, no markdown formatting."""

    def _enhance_with_fuzzy_scores(
        self, ai_result: dict[str, Any], receipt_items: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Enhance AI results with fuzzy matching confidence scores."""
        # Create a lookup dict for receipt items by ID
        receipt_lookup = {item["id"]: item for item in receipt_items}

        # Enhance each participant's orders with fuzzy scores
        for participant in ai_result.get("participants", []):
            for order in participant.get("orders", []):
                receipt_item_id = order.get("receipt_item_id")
                receipt_item = receipt_lookup.get(receipt_item_id)

                if receipt_item:
                    # Calculate fuzzy match score between mentioned name and actual name
                    mentioned_name = order.get("matching_notes", "").lower()
                    actual_name = receipt_item["name"].lower()

                    # Use token sort ratio for better matching
                    fuzzy_score = fuzz.token_sort_ratio(mentioned_name, actual_name) / 100.0

                    # Combine AI confidence with fuzzy score (weighted average)
                    ai_confidence = order.get("confidence", 0.8)
                    combined_confidence = (ai_confidence * 0.7) + (fuzzy_score * 0.3)

                    order["fuzzy_score"] = round(fuzzy_score, 2)
                    order["confidence"] = round(combined_confidence, 2)

        return ai_result

    def calculate_fuzzy_score(self, text1: str, text2: str) -> float:
        """Calculate fuzzy matching score between two text strings.

        Args:
            text1: First text string
            text2: Second text string

        Returns:
            Confidence score between 0.0 and 1.0
        """
        # Use token sort ratio which handles word order differences
        score = fuzz.token_sort_ratio(text1.lower(), text2.lower())
        return score / 100.0

    def format_matching_results(self, matching_result: dict[str, Any]) -> str:
        """Format matching results as a user-friendly message.

        Args:
            matching_result: Result from match_items()

        Returns:
            Formatted message string for Telegram
        """
        lines = ["🎯 **Item Matching Complete!**\n"]

        participants = matching_result.get("participants", [])
        if not participants:
            return "⚠️ I couldn't identify any participants from your message. Please try again."

        # Show matched participants
        for participant in participants:
            name = participant.get("name", "Unknown")
            orders = participant.get("orders", [])

            lines.append(f"👤 **{name}:**")
            if orders:
                for order in orders:
                    item_name = order.get("receipt_item_name", "Unknown")
                    qty_share = order.get("quantity_share", 1.0)
                    confidence = order.get("confidence", 0.0)

                    confidence_emoji = "✅" if confidence >= 0.9 else "⚠️" if confidence >= 0.7 else "❓"

                    if qty_share < 1.0:
                        lines.append(
                            f"  {confidence_emoji} {item_name} ({qty_share * 100:.0f}% share) - confidence: {confidence:.0%}"
                        )
                    else:
                        lines.append(f"  {confidence_emoji} {item_name} - confidence: {confidence:.0%}")
            else:
                lines.append("  • (no items)")
            lines.append("")

        # Show unmatched items if any
        unmatched = matching_result.get("unmatched_items", [])
        if unmatched:
            lines.append("⚠️ **Unassigned Items:**")
            for item in unmatched:
                item_name = item.get("receipt_item_name", "Unknown")
                reason = item.get("reason", "Not mentioned")
                lines.append(f"  • {item_name} - {reason}")
            lines.append("")

        # Show ambiguities if any
        ambiguities = matching_result.get("ambiguities", [])
        if ambiguities:
            lines.append("❓ **Ambiguous Matches:**")
            for amb in ambiguities:
                participant = amb.get("participant", "Unknown")
                mentioned = amb.get("mentioned_item", "item")
                lines.append(f"  • {participant} mentioned '{mentioned}' - multiple possible matches")
            lines.append("")

        # Add notes
        if matching_result.get("notes"):
            lines.append(f"📝 *{matching_result['notes']}*\n")

        lines.append("---\n")
        lines.append("Is this correct? Reply **'yes'** to calculate the split, or **'edit'** to make corrections.")

        return "\n".join(lines)
