"""Split calculator for proportional tax/tip distribution."""

import logging
from typing import Any

logger = logging.getLogger(__name__)


class SplitCalculator:
    """Calculate bill splits with proportional tax and tip distribution."""

    def calculate_split(
        self,
        participants_data: list[dict[str, Any]],
        receipt_data: dict[str, Any],
        distribution_method: str = "proportional",
    ) -> dict[str, Any]:
        """Calculate the bill split for all participants.

        Args:
            participants_data: List of participants with their matched orders
                [
                    {
                        "name": "You",
                        "participant_id": 1,
                        "orders": [
                            {
                                "receipt_item_id": 1,
                                "receipt_item_name": "Burger",
                                "unit_price": 12.99,
                                "quantity_share": 1.0
                            }
                        ]
                    }
                ]
            receipt_data: Receipt information with subtotal, tax, tip, total
            distribution_method: "proportional" or "equal" for tax/tip

        Returns:
            Dictionary containing participant splits and totals
        """
        logger.info(
            f"Calculating split for {len(participants_data)} participants using {distribution_method} method"
        )

        # Step 1: Calculate individual item totals
        participant_splits = []
        total_assigned_subtotal = 0.0

        for participant_data in participants_data:
            participant_split = {
                "name": participant_data["name"],
                "participant_id": participant_data.get("participant_id"),
                "items": [],
                "items_subtotal": 0.0,
                "tax_share": 0.0,
                "tip_share": 0.0,
                "final_total": 0.0,
            }

            # Calculate subtotal from items
            for order in participant_data.get("orders", []):
                unit_price = order.get("unit_price", 0.0)
                quantity_share = order.get("quantity_share", 1.0)
                item_total = unit_price * quantity_share

                participant_split["items"].append(
                    {
                        "name": order.get("receipt_item_name", "Unknown"),
                        "unit_price": unit_price,
                        "quantity_share": quantity_share,
                        "item_total": item_total,
                    }
                )

                participant_split["items_subtotal"] += item_total

            total_assigned_subtotal += participant_split["items_subtotal"]
            participant_splits.append(participant_split)

        # Step 2: Handle unassigned items (scale proportionally if needed)
        receipt_subtotal = receipt_data.get("subtotal", receipt_data.get("total", 0.0))
        if total_assigned_subtotal < receipt_subtotal - 0.01:  # Allow for rounding
            logger.warning(
                f"Items subtotal ({total_assigned_subtotal:.2f}) "
                f"is less than receipt subtotal ({receipt_subtotal:.2f})"
            )
            # Scale up proportionally to account for unassigned items
            scale_factor = receipt_subtotal / total_assigned_subtotal if total_assigned_subtotal > 0 else 1.0
            logger.info(f"Applying scale factor of {scale_factor:.2f} to account for unassigned items")

            for split in participant_splits:
                split["items_subtotal"] *= scale_factor
        else:
            receipt_subtotal = total_assigned_subtotal  # Use actual subtotal if higher

        # Step 3: Distribute tax
        tax = receipt_data.get("tax", 0.0)
        if distribution_method == "proportional":
            for split in participant_splits:
                proportion = split["items_subtotal"] / receipt_subtotal if receipt_subtotal > 0 else 0
                split["tax_share"] = tax * proportion
        elif distribution_method == "equal":
            tax_per_person = tax / len(participant_splits) if participant_splits else 0
            for split in participant_splits:
                split["tax_share"] = tax_per_person
        else:
            raise ValueError(f"Invalid distribution_method: {distribution_method}")

        # Step 4: Distribute tip
        tip = receipt_data.get("tip", 0.0)
        if distribution_method == "proportional":
            for split in participant_splits:
                proportion = split["items_subtotal"] / receipt_subtotal if receipt_subtotal > 0 else 0
                split["tip_share"] = tip * proportion
        elif distribution_method == "equal":
            tip_per_person = tip / len(participant_splits) if participant_splits else 0
            for split in participant_splits:
                split["tip_share"] = tip_per_person

        # Step 5: Calculate final amounts
        for split in participant_splits:
            split["final_total"] = split["items_subtotal"] + split["tax_share"] + split["tip_share"]

        # Step 6: Adjust for rounding errors
        total_calculated = sum(split["final_total"] for split in participant_splits)
        receipt_total = receipt_data.get("total", 0.0)
        difference = receipt_total - total_calculated

        if abs(difference) > 0.01:
            logger.info(f"Rounding adjustment needed: {difference:.2f}")
            # Add difference to person with largest amount
            largest_split = max(participant_splits, key=lambda s: s["final_total"])
            largest_split["final_total"] += difference
            largest_split["rounding_adjustment"] = difference
            logger.info(f"Added rounding adjustment of {difference:.2f} to {largest_split['name']}")

        # Step 7: Round all amounts to 2 decimal places
        for split in participant_splits:
            split["items_subtotal"] = round(split["items_subtotal"], 2)
            split["tax_share"] = round(split["tax_share"], 2)
            split["tip_share"] = round(split["tip_share"], 2)
            split["final_total"] = round(split["final_total"], 2)

            for item in split["items"]:
                item["item_total"] = round(item["item_total"], 2)

        # Build result
        result = {
            "participants": participant_splits,
            "receipt_total": receipt_total,
            "distribution_method": distribution_method,
            "summary": {
                "total_calculated": round(sum(s["final_total"] for s in participant_splits), 2),
                "total_subtotal": round(sum(s["items_subtotal"] for s in participant_splits), 2),
                "total_tax": round(sum(s["tax_share"] for s in participant_splits), 2),
                "total_tip": round(sum(s["tip_share"] for s in participant_splits), 2),
            },
        }

        logger.info(f"Split calculation complete. Total: ${result['summary']['total_calculated']:.2f}")
        return result

    def format_split_results(self, split_result: dict[str, Any]) -> str:
        """Format split results as a user-friendly message.

        Args:
            split_result: Result from calculate_split()

        Returns:
            Formatted message string for Telegram
        """
        lines = ["💰 **Bill Split Complete!**\n"]

        receipt_total = split_result.get("receipt_total", 0.0)
        participants = split_result.get("participants", [])

        lines.append(f"**Total Bill:** ${receipt_total:.2f}\n")
        lines.append(f"**Split between {len(participants)} people:**\n")

        # Show each participant's breakdown
        for split in participants:
            name = split.get("name", "Unknown")
            final_total = split.get("final_total", 0.0)

            lines.append(f"👤 **{name}** - ${final_total:.2f}")

            # Show items
            for item in split.get("items", []):
                item_name = item.get("name", "Unknown")
                item_total = item.get("item_total", 0.0)
                qty_share = item.get("quantity_share", 1.0)

                if qty_share < 1.0:
                    lines.append(f"  • {item_name} (${item_total:.2f}) - {qty_share * 100:.0f}% share")
                else:
                    lines.append(f"  • {item_name} (${item_total:.2f})")

            # Show tax and tip
            tax_share = split.get("tax_share", 0.0)
            tip_share = split.get("tip_share", 0.0)
            lines.append(f"  • Tax: ${tax_share:.2f}")
            lines.append(f"  • Tip: ${tip_share:.2f}")

            # Show rounding adjustment if any
            if "rounding_adjustment" in split:
                adj = split["rounding_adjustment"]
                lines.append(f"  • Rounding adjustment: ${adj:+.2f}")

            lines.append("")

        # Verification
        summary = split_result.get("summary", {})
        total_calculated = summary.get("total_calculated", 0.0)
        distribution_method = split_result.get("distribution_method", "proportional")

        lines.append("---")
        lines.append(f"✅ All items assigned")
        lines.append(f"💵 Total verified: ${total_calculated:.2f}")
        lines.append(f"📊 Tax/Tip distribution: {distribution_method.title()}\n")

        return "\n".join(lines)

    def format_detailed_breakdown(self, split_result: dict[str, Any]) -> str:
        """Format detailed breakdown with calculations shown.

        Args:
            split_result: Result from calculate_split()

        Returns:
            Formatted detailed message string
        """
        lines = ["📊 **Detailed Breakdown**\n"]

        participants = split_result.get("participants", [])
        receipt_total = split_result.get("receipt_total", 0.0)

        for split in participants:
            name = split.get("name", "Unknown")
            items_subtotal = split.get("items_subtotal", 0.0)
            tax_share = split.get("tax_share", 0.0)
            tip_share = split.get("tip_share", 0.0)
            final_total = split.get("final_total", 0.0)

            # Calculate percentages
            if receipt_total > 0:
                percentage = (items_subtotal / receipt_total) * 100
            else:
                percentage = 0

            lines.append(f"**{name}:**")
            lines.append(f"├─ Items: ${items_subtotal:.2f}")

            for item in split.get("items", []):
                item_name = item.get("name", "Unknown")
                item_total = item.get("item_total", 0.0)
                lines.append(f"│  ├─ {item_name}: ${item_total:.2f}")

            lines.append(f"├─ Tax ({percentage:.1f}%): ${tax_share:.2f}")
            lines.append(f"├─ Tip ({percentage:.1f}%): ${tip_share:.2f}")
            lines.append(f"└─ **Total: ${final_total:.2f}**\n")

        # Calculation method
        lines.append("**Calculation Method:**")
        distribution_method = split_result.get("distribution_method", "proportional")
        if distribution_method == "proportional":
            lines.append("• Tax/tip split proportionally based on item costs")
        else:
            lines.append("• Tax/tip split equally among all participants")
        lines.append("• Shared items divided by participant count")

        # Show rounding
        has_adjustment = any("rounding_adjustment" in s for s in participants)
        if has_adjustment:
            lines.append("• Rounding adjustment applied to largest amount\n")

        return "\n".join(lines)
